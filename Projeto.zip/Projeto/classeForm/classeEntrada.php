<?php

    abstract class Entrada{
        public $name; //null
        public $placeholder; //null
        public $value; // null
        public $required;
        public $class;
        public $id;
        public $label;

    }

?>