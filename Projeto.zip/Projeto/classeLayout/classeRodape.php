<?php

    class Rodape{

        function exibe(){
            echo '
                <script src="js/popper.min.js"></script>
                <script src="js/jquery-3.2.1.min.js"></script>
                <script src="js/bootstrap.min.js"></script>
                <script src="js/bootstrap-datepicker.min.js"></script>
                <script src="js/bootstrap-datepicker.pt-BR.min.js"></script>                
                <script src="js/MD5.js"></script>
                <script src="js/index.js"></script>
                <script src="js/inserir_editar_remover.js"></script>
            </body>
            </html>';
        }


    }


?>