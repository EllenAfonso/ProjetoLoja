<?php

include "validacaoUsuario.php";
$_SESSION["usuario"]["permissao"] = 2;

if($_SESSION["usuario"]["permissao"]!="1"){

include "conexao.php";

//header("Content-Type: Application/json");

$nome = $_POST["nome"];
$sobrenome = $_POST["sobrenome"];
$data_nascimento = $_POST["data_nascimento"];
$rua = $_POST["rua"];
$numero = $_POST["numero"];
$compl = $_POST["compl"];
$bairro = $_POST["bairro"];
$cidade = $_POST["cidade"];
$estado = $_POST["estado"];
$cep = $_POST["cep"];
$cpf = $_POST["cpf"];
$rg = $_POST["rg"];
$telefone = $_POST["telefone"];
$nome_usuario = $_POST["email"];
$senha = $_POST["senha"];
$permissao = "2";
$email = $_POST["email"];

$insert = "INSERT INTO usuario(nome, sobrenome, data_nascimento, rua, numero, compl, bairro, cidade, estado, 
            cep, cpf, rg, telefone, nome_usuario, senha, permissao, email) 
                VALUES ('$nome','$sobrenome','$data_nascimento','$rua','$numero','$compl','$bairro',
                '$cidade','$estado','$cep','$cpf','$rg','$telefone','$nome_usuario','$senha','$permissao','$email')";


$conexao->query($insert);


    header("location: login.php");


?>