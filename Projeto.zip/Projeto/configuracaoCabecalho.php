<?php
$p["logo"] = "img/logo.png";
$p["alt_logo"] = "Logotipo Collection";
    $p["links"][0]["link"] = "usuario.php";
    $p["links"][0]["label"] = "Usuarios";
    $p["links"][1]["link"] = "produto.php";
    $p["links"][1]["label"] = "Produtos";
    $p["links"][2]["link"] = "categoria.php";
    $p["links"][2]["label"] = "Categorias";
    $p["links"][3]["link"] = "carrinho.php";
    $p["links"][3]["label"] = "Carrinhos";
    $p["links"][4]["link"] = "carrinho_produto.php";
    $p["links"][4]["label"] = "Carrinho_Produtos"; 
    $p["links"][5]["link"] = "venda.php";
    $p["links"][5]["label"] = "Vendas"; 
?>