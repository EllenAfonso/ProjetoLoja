DROP DATABASE IF EXISTS loja;

CREATE DATABASE IF NOT EXISTS loja;

USE loja;

-- TABELA USUARIO
CREATE TABLE IF NOT EXISTS usuario (
	id_usuario INT not null auto_increment primary key,
    nome_usuario VARCHAR(100) not null,
    senha CHAR(32) not null,
    permissao int not null,
    email VARCHAR(20) not null
    nome VARCHAR(100) not null,
	sobrenome  VARCHAR(100) not null,
    data_nascimento DATE not null,
    rua VARCHAR(100) not null,
    numero INT not null,
    compl VARCHAR(100),
    bairro VARCHAR(100) not null,
    cidade VARCHAR(100) not null,
    estado CHAR(2) not null,
    cep CHAR(8) not null,
    cpf CHAR(11) not null,
    rg CHAR(9) not null,
    telefone VARCHAR(50) not null,
   
);
-- TABELA CATEGORIA
CREATE TABLE IF NOT EXISTS categoria (
    id_categoria INT not null auto_increment primary key,
    tipo VARCHAR(50) not null
);
-- TABELA PRODUTO
CREATE TABLE IF NOT EXISTS produto (
    id_produto INT not null auto_increment primary key,
    nome_produto VARCHAR(50) not null,
    descricao VARCHAR(50) not null,
    peso INT not null,
    tamanho VARCHAR(50) not null,
    cor VARCHAR(50) not null,
    cod_categoria INT not null,
    preco  FLOAT(6 , 2) not null,
    estoque INT not null,
    FOREIGN KEY (cod_categoria) REFERENCES categoria (id_categoria)
);
-- TABELA CARRINHO
CREATE TABLE IF NOT EXISTS carrinho (
    id_carrinho INT not null auto_increment primary key,
    id_usuario INT not null,
    FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
);
-- TABELA CARRINHO_PRODUTO
CREATE TABLE IF NOT EXISTS carrinho_produto (
    cod_produto INT not null,
    qtde INT not null,
    cod_carrinho INT not null,
    primary key (cod_produto, cod_carrinho),
    FOREIGN KEY (cod_produto) REFERENCES produto (id_produto),
	FOREIGN KEY (cod_carrinho) REFERENCES carrinho (id_carrinho)
);
-- TABELA VENDA
CREATE TABLE IF NOT EXISTS venda (
    id_venda INT not null auto_increment primary key,
    cod_carrinho INT not null,
    horario TIME not null,
    data DATE not null,
    status VARCHAR(50) not null,
    valor FLOAT(6 , 2) not null,
	endereco_entrega VARCHAR(100) not null,
    valor_frete FLOAT(6 , 2) not null,
    FOREIGN KEY (cod_carrinho) REFERENCES carrinho (id_carrinho)
);
-- INSERÇÕES

INSERT INTO usuario (nome, sobrenome, data_nascimento, rua, numero, compl, bairro, cidade,
 estado, telefone, 
 cep, cpf, rg, id_usuario, nome_usuario, email, senha, permissao) 
VALUES
(upper('Fernando'), upper(' Wong'), '1955-12-08', 'Rua da Lapa', 34, NULL, 'Mooca','São Paulo', 'SP','33333333', 12345-000, '12345604538', '245448345',1, 'cliente', 'fernando@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 2),

(upper('Ellen'),upper(' Afonso'), '1990-11-10', 'Rua Matão', 102, null, 'Jd Adalberto Roxo', 'Araraquara', 'SP',  '1633326849', 14810-300 , '11144455555', '123678567',2,'Admin','ellen@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 1);



INSERT INTO categoria (id_categoria, tipo)
values
(1, 'Blusa'),
(2, 'Body'),
(3, 'Calça'),
(4, 'Jardineira'),
(5, 'Macacão'),
(6, 'Short'),
(7, 'Vestido');

INSERT INTO produto (id_produto, nome_produto, descricao, peso, tamanho, cor, cod_categoria, preco, estoque)
values
(10, 'Blusa Copacabana', 'tecido em organza com forro bege', 80,' M', 'amarela', 1, '35.50', 50),
(20, 'Blusa Inovation', 'tecido em malha com babados', 82,' G', 'rosa', 1,'25.50', 50),
(30, 'Calça Staroup', 'jeans com lycra desbotada', 135,' M', 'jeans', 3,'60.00', 50),
(40, 'Calça Trend', 'tecido de brim com lycra', 130,' M', 'preta', 3, '35.50', 50),
(50, 'Body Bruna', 'tecido de poliamida em lycra', 92,' P','rosa', 2, '40.50', 50),
(60, 'Body Station', 'tecido em malha com lycra e marga curta', 93,' GG', 'preto', 2, '35.50', 50),
(70, 'Vestido Sabrina', 'tecido em organza com forro bege', 100,' M','preto', 7, '55.50', 50),
(80, 'Vestido Origem', 'tecido em algodão com forro bege', 110,' P', 'amarelo', 7, '57.50', 50),
(90, 'Short Adidas', 'tecido em brim com detalhes de lantejoulas', 80, 'cinza',' M', 6, '41.00', 50),
(100, 'Short Love', 'tecido em organza com forro bege', 130,' M', 'vinho', 6, '38.50', 50),
(110, 'Macacão Blumenau', 'tecido em jeans com lycra', 140,' M', 'jeans', 5, '65.00', 50),
(120, 'Jardineira Paloma', 'tecido em brim desbotado', 100, 'azul',' XG', 4, '50.50', 50),
(130, 'Body Bruna', 'tecido de poliamida em lycra', 96,' M','rosa', 2, '40.50', 50),
(140, 'Macacão Blumenau', 'tecido em jeans com lycra', 160,' GG', 'jeans', 5, '65.00', 50),
(150, 'Blusa Inovation', 'tecido em malha com babados', 82,' XG', 'cinza', 1, '25.50', 50);

select * from categoria;


drop view if exists view_produto;
CREATE VIEW view_produto As
SELECT produto.id_produto 'id_produto', 
		produto.nome_produto 'nome',
        produto.descricao 'descricao', 
        produto.peso 'peso',
		produto.tamanho 'tamanho',
		produto.cor 'cor', 
		categoria.tipo 'tipo', 
		produto.valor_unitario 'valor_unitario',
		produto.estoque 'estoque' 
FROM produto INNER JOIN categoria ON produto.cod_categoria = categoria.id_categoria;
select * from view_produto;

INSERT INTO carrinho (id_carrinho, id_usuario)
values
(1, 1),


drop view if exists view_carrinho;
CREATE VIEW view_carrinho As
SELECT carrinho.id_carrinho 'id_carrinho', 
		usuario.nome 'nome',
        usuario.sobrenome 'sobrenome', 
        usuario.cpf 'cpf'
FROM carrinho INNER JOIN usuario ON carrinho.id_usuario = usuario.id_usuario;
select * from view_carrinho;

INSERT INTO carrinho_produto (cod_produto, qtde, cod_carrinho)
values
(10, 1, 1),


drop view if exists view_carrinho_produto;
CREATE VIEW view_carrinho_produto As
SELECT 
		usuario.nome 'nome',
        usuario.sobrenome 'sobrenome', 
        usuario.cpf 'cpf',
		produto.nome_produto 'nome_produto',
		produto.descricao 'descricao', 
        produto.peso 'peso',
		produto.tamanho 'tamanho',
		produto.cor 'cor',
        c.qtde 'quantidade',
		produto.valor_unitario 'valor_unitario'
FROM ((carrinho_produto c
	INNER JOIN produto ON c.cod_produto = produto.id_produto)
	INNER JOIN carrinho ON c.cod_carrinho = carrinho.id_carrinho
		INNER JOIN cliente ON  carrinho.id_usuario = usuario.id_usuario);
select * from view_carrinho_produto;


INSERT INTO venda (id_venda, cod_carrinho, horario, data, status, valor, endereco_entrega, valor_frete)
values
(1, 1, 10.30, '2020-10-08','Pago', '35.50','Rua da Lapa, 34 - Mooca / SP', 15.00);

drop view if exists view_venda;
CREATE VIEW view_venda As
SELECT  
		usuario.nome 'Nome',
        usuario.sobrenome 'Sobrenome', 
        usuario.cpf 'CPF',
		venda.id_venda 'id_venda', 
		venda.horario 'Horario',
        venda.data 'Data', 
        venda.status 'Status',
		venda.valor'Valor',
		venda.endereco_entrega 'Endereco de Entrega', 
		venda.valor_frete 'Valor do frete'
FROM venda 
	INNER JOIN carrinho ON venda.cod_carrinho = carrinho.id_usuario
	INNER JOIN usuario ON usuario.id_usuario = id_usuario.carrinho;
    
select * from view_venda;


drop trigger if exists after_venda_insert;
create
	trigger after_carrinho_produto_insert
after insert on carrinho_produto for each row
	update produto set estoque = estoque - new.qtde where
		id_produto = new.id_produto;
        
show triggers;
select * from estoque;
