<?php
    $p = null;
    $p["cabecalho"] = array("Nome","Sobrenome","Data de Nascimento","Rua/AV.","Numero","Complemento","Bairro",
    "Cidade","Estado","CEP","CPF","RG","Telefone","Nome Usuario","Senha","Permissao","E-mail");

    include "conexao.php";

    $sql = "SELECT * FROM usuario ORDER BY nome";

    $resultado = $conexao->query($sql);

    foreach($resultado as $linha){
        $p["dados"][]=$linha;
    }
    $p["nome"] = "usuario";
?>