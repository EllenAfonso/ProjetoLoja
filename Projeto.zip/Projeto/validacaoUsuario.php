<?php

session_start();

/*if(!isset($_SESSION["usuario"]["permissao"])){
    header("location: login.php");
}*/



?>