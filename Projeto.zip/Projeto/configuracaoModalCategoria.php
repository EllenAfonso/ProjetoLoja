<?php

$p["id"] = "Categoria";
$p["titulo"] = "Categoria";

$p["divRow"][0] = '
<div class="row">
    <div class="form-group col-sm-6 col-6">	                            
        <input type="text" name="tipo" 
        id="tipo" class="form-control" placeholder= "Tipo..."/>
    </div>
</div>';
?>