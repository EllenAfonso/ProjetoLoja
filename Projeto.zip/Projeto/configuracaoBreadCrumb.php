<?php
$p = null;

$p["links"][0]["link"] = "index.php";
$p["links"][0]["label"] = "";

if(isset($titulo)){
    $p["links"][1]["link"] = strtolower($titulo).".php";
    $p["links"][1]["label"] = $titulo;

    $p["links"][2]["link"] = "";
    $p["links"][2]["label"] = "Pesquisa";
}   

?>