<?php

include("validacaoUsuario.php");

if($_SESSION["usuario"]["permissao"]!="2" && $_SESSION["usuario"]["permissao"]!="2"){


header("Content-Type: Application/json");

include "conexao.php";
$nome = $_POST["nome"];
$sobrenome = $_POST["sobrenome"];
$data_nascimento = $_POST["data_nascimento"];
$rua = $_POST["rua"];
$numero = $_POST["numero"];
$compl = $_POST["compl"];
$bairro = $_POST["bairro"];
$cidade = $_POST["cidade"];
$estado = $_POST["estado"];
$cep = $_POST["cep"];
$cpf = $_POST["cpf"];
$rg = $_POST["rg"];
$telefone = $_POST["telefone"];
$nome_usuario = $_POST["nome_usuario"];
$senha = $_POST["senha"];
$permissao = $_POST["permissao"];
$email = $_POST["email"];
$id = $_POST["id_usuario"];

$update = "UPDATE usuario SET nome='$nome', cidade='$cidade', sobrenome='$sobrenome', data_nascimento='$data_nascimento,
     rua='$rua', numero='$numero', compl='$compl', bairro='$bairro', cidade='$cidade', estado='$estado', cep='$cep',
      cpf='$cpf', rg='$rg', telefone='$telefone', nome_usuario='$nome_usuario', senha='$senha', permissao='$permissao',
       email='$email' WHERE id_usuario='$id'";

$conexao->query($update);

$select = "SELECT * FROM usuario ORDER BY nome";

$resultado = $conexao->query($select);


foreach($resultado as $linha){
    $tabela[] = $linha;
}

echo json_encode($tabela);
}
else{
    header("location: login.php");
}
?>